var zoom_pics = document.getElementById("zoom");
var zoompic = document.getElementById("zoompic");
var favoritesArea = document.getElementById("favoritesArea");
var zoomCaption = document.getElementById("zoomCaption");

function openZoomPic(img, caption) {
  zoompic.src = img;
  zoomCaption.textContent = caption;
  zoom_pics.style.display = "flex";
}

function closeZoomPic() {
  zoom_pics.style.display = "none";
}

document.addEventListener("DOMContentLoaded", function () {
  closeZoomPic();
});

let scrollContainer = document.querySelector(".album");
let leftButton = document.getElementById("left_btn");
let rightButton = document.getElementById("right_btn");

rightButton.addEventListener("click", () => {
  scrollContainer.style.scrollBehavior = "smooth";
  scrollContainer.scrollLeft += 900;
});

leftButton.addEventListener("click", () => {
  scrollContainer.style.scrollBehavior = "smooth";
  scrollContainer.scrollLeft -= 900;
});

function addToFavorites() {
  var currentFavoritesCount = favoritesArea.childElementCount;

  if (currentFavoritesCount < 5) {
    var favoriteContainer = document.createElement("div");
    favoriteContainer.classList.add("favorite-container");

    var favoriteImage = document.createElement("img");
    favoriteImage.src = zoompic.src;
    favoriteImage.alt = "Favorite";
    favoriteImage.classList.add("favorite-img");

    var removeLink = document.createElement("a");
    removeLink.href = "#";
    removeLink.textContent = "Remove";
    removeLink.classList.add("remove-link");
    removeLink.onclick = function () {
      removeFromFavorites(favoriteContainer);
    };

    favoriteContainer.appendChild(favoriteImage);
    favoriteContainer.appendChild(removeLink);
    favoritesArea.appendChild(favoriteContainer);
    openZoomPic(zoompic.src, zoomCaption.textContent);
  } else {
    alert(
      "You can only add a maximum of 5 favorites. Remove at least one favorite first."
    );
  }
}

function removeFromFavorites(container) {
  favoritesArea.removeChild(container);
}
